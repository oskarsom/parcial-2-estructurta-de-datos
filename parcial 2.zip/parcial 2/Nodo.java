public class Nodo {
    Moto moto;
    Nodo izquierdo;
    Nodo derecho;

    public Nodo(Moto moto) {
        this.moto = moto;
    }
}
