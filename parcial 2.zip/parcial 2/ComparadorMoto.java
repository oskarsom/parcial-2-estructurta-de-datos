import java.util.Comparator;

public class ComparadorMoto {

    public static Comparator<Moto> porMarca() {
        return Comparator.comparing(Moto::getMarca);
    }

    public static Comparator<Moto> porKilometraje() {
        return Comparator.comparingInt(Moto::getKilometraje);
    }

    public static Comparator<Moto> porColor() {
        return Comparator.comparing(Moto::getColor);
    }

    public static Comparator<Moto> porTipo() {
        return Comparator.comparing(Moto::getTipo);
    }
}