import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class BuscadorMotos {
    private ArbolBinarioBusqueda arbol;

    public BuscadorMotos(ArbolBinarioBusqueda arbol) {
        this.arbol = arbol;
    }

    public List<Moto> buscar(Predicate<Moto> criterio) {
        List<Moto> resultado = new ArrayList<>();
        arbol.inorden(moto -> {
            if (criterio.test(moto)) {
                resultado.add(moto);
            }
        });
        return resultado;
    }
}