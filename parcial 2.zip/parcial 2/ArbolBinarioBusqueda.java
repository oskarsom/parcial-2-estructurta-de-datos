import java.util.Comparator;
import java.util.function.Consumer;

public class ArbolBinarioBusqueda {
    private Nodo raiz;
    private Comparator<Moto> comparador;

    public ArbolBinarioBusqueda(Comparator<Moto> comparador) {
        this.comparador = comparador;
    }

    public void insertar(Moto moto) {
        raiz = insertarRecursivo(raiz, moto);
    }

    private Nodo insertarRecursivo(Nodo actual, Moto moto) {
        if (actual == null) {
            return new Nodo(moto);
        }

        int comparacion = comparador.compare(moto, actual.moto);

        if (comparacion < 0) {
            actual.izquierdo = insertarRecursivo(actual.izquierdo, moto);
        } else if (comparacion > 0) {
            actual.derecho = insertarRecursivo(actual.derecho, moto);
        } else {
            return actual;
        }

        return actual;
    }

    public void inorden(Consumer<Moto> action) {
        inordenRecursivo(raiz, action);
    }

    private void inordenRecursivo(Nodo actual, Consumer<Moto> action) {
        if (actual != null) {
            inordenRecursivo(actual.izquierdo, action);
            action.accept(actual.moto);
            inordenRecursivo(actual.derecho, action);
        }
    }
}